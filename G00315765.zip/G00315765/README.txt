# Artificial Intelligence 50% Assignment  
## Using Simulated Annealing to Break a Playfair Cipher  

This project is for my Artificial Intelligence module. By the time of the due date (Sunday 8th April, midnight) I did not have the project working. I was getting a null point error that I could not figure out and didn't want to submit the project late.

## Features of this Project  

1. Decrypt  
2. Exit  

A third element that was required was Simulated Annealing which I did not get done before the deadline, partly because I have an error for the first part but also because I did not full understand Simulated Annealing.


### Decrypt  
When you chose to decrypt you are asked then to enter the name of the file you would like to decrypt. You do not need to add the file type (eg .txt) as I have a piece of code that adds that to the file name. Then a key is randomly generated, this is then supposed to be used to try and decrypt the file that has been requested.  

### Exit  
Exit simply stops the application running.  

## Running the Application  
To run this application simply type **java -cp ./playfair.jar ie.gmit.sw.ai.CipherBreaker** into the command line where ever you download this repo, making sure that the text file you want to decrypt is in the same place. Otherwise drag the src folder into Eclipse.
